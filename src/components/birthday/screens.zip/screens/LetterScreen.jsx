import { useEffect, useRef, useState } from "react";
import { COLORS, LETTER_TEXT } from "../constants";
import Tag from "../shared/Tag";
import Btn from "../shared/Btn";

export default function LetterScreen() {
  const [typed, setTyped] = useState("");
  const [done, setDone] = useState(false);
  const started = useRef(false);

  // With routing, this component only mounts once the route is actually
  // active, so the typewriter can just start on mount (no "active" prop
  // needed like in the old single-file version).
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    let i = 0;
    const step = () => {
      if (i <= LETTER_TEXT.length) {
        setTyped(LETTER_TEXT.slice(0, i));
        i++;
        setTimeout(step, 22);
      } else {
        setDone(true);
      }
    };
    step();
  }, []);

  return (
    <div className="max-w-md sm:max-w-lg mx-auto w-full">
      <Tag>the last page</Tag>
      <h2 className="mt-2 mb-5 italic text-xl sm:text-2xl" style={{ fontFamily: "'Playfair Display', serif" }}>
        a letter for you
      </h2>
      <div
        className="text-left font-mono text-xs sm:text-sm leading-relaxed rounded-xl px-5 sm:px-6 py-6 sm:py-7 min-h-[260px] sm:min-h-[300px] whitespace-pre-wrap"
        style={{ background: "rgba(255,255,255,0.35)", border: `1px solid ${COLORS.line}`, color: COLORS.brown }}
      >
        {typed}
        <span className="quest-cursor inline-block w-2 h-4 align-text-bottom ml-0.5" style={{ background: COLORS.rust }} />
      </div>
      {done && (
        <div className="flex justify-center">
          <Btn onClick={() => window.questBurst && window.questBurst()} className="mt-6">
            happy birthday 🎉
          </Btn>
        </div>
      )}
    </div>
  );
}