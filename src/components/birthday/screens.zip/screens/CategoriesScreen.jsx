import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { COLORS, CATEGORIES } from "../constants";
import { useQuestProgress } from "../hooks/useQuestProgress";
import Tag from "../shared/Tag";
import Btn from "../shared/Btn";

export default function CategoriesScreen() {
  const navigate = useNavigate();
  const { unlock } = useQuestProgress();
  const [active, setActive] = useState("childhood");
  const cat = CATEGORIES.find((c) => c.id === active);

  const onContinue = () => {
    unlock("balloons");
    navigate("/quest/balloons");
  };

  return (
    <div>
      <Tag>a little archive of us</Tag>
      <h2 className="mt-2 italic text-xl sm:text-2xl" style={{ fontFamily: "'Playfair Display', serif" }}>
        through the years
      </h2>

      <div className="flex gap-1.5 sm:gap-2 justify-center flex-wrap mt-4">
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            onClick={() => setActive(c.id)}
            className="text-xs sm:text-sm font-semibold px-3.5 sm:px-4 py-2 rounded-full transition-colors"
            style={
              active === c.id
                ? { background: COLORS.rust, color: COLORS.cream, border: `1.5px solid ${COLORS.rust}` }
                : { background: "rgba(255,255,255,0.3)", color: COLORS.brown, border: `1.5px solid ${COLORS.line}` }
            }
          >
            {c.label}
          </button>
        ))}
      </div>

      <div className="mt-6">
        {active === "song" ? (
          <>
            <div
              className="w-48 h-48 sm:w-52 sm:h-52 mx-auto rounded-xl flex flex-col items-center justify-center text-center p-4 text-2xl sm:text-3xl font-mono"
              style={{
                background:
                  "repeating-linear-gradient(135deg, rgba(94,70,50,0.06), rgba(94,70,50,0.06) 10px, rgba(94,70,50,0.02) 10px, rgba(94,70,50,0.02) 20px)",
                border: `1px solid ${COLORS.line}`,
                color: COLORS.brownSoft,
              }}
            >
              🎵
              <span className="quest-editable text-xs sm:text-sm mt-1">[his favorite song name]</span>
            </div>
            <p className="mt-3.5 text-sm" style={{ color: COLORS.brown }}>
              add his favorite track at public/audio/soft-bgm.mp3
            </p>
            <audio controls className="mt-2.5 w-full max-w-xs mx-auto block">
              <source src="/audio/soft-bgm.mp3" type="audio/mpeg" />
            </audio>
          </>
        ) : (
          <>
            <div
              className="w-48 h-48 sm:w-52 sm:h-52 mx-auto rounded-xl flex items-center justify-center text-center p-3.5 font-mono text-xs sm:text-sm"
              style={{
                background:
                  "repeating-linear-gradient(135deg, rgba(94,70,50,0.06), rgba(94,70,50,0.06) 10px, rgba(94,70,50,0.02) 10px, rgba(94,70,50,0.02) 20px)",
                border: `1px solid ${COLORS.line}`,
                color: COLORS.brownSoft,
              }}
            >
              dummy photo — replace with a {cat.label.toLowerCase()} pic
            </div>
            <p className="mt-3.5 text-sm sm:text-base leading-relaxed" style={{ color: COLORS.brown }}>
              <span className="quest-editable">{cat.caption}</span>
            </p>
          </>
        )}
      </div>

      <Btn onClick={onContinue} className="mt-6">
        continue →
      </Btn>
    </div>
  );
}