import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { COLORS, PUZZLE_EMOJIS } from "../constants";
import { useQuestProgress } from "../hooks/useQuestProgress";
import Tag from "../shared/Tag";
import Btn from "../shared/Btn";

function shuffledDeck() {
  const deck = [...PUZZLE_EMOJIS, ...PUZZLE_EMOJIS].map((val, i) => ({ id: i, val }));
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

export default function PuzzleScreen() {
  const navigate = useNavigate();
  const { unlock } = useQuestProgress();
  const [deck] = useState(shuffledDeck);
  const [flipped, setFlipped] = useState([]);
  const [matched, setMatched] = useState([]);
  const [lock, setLock] = useState(false);

  const handleFlip = (card) => {
    if (lock || flipped.includes(card.id) || matched.includes(card.id)) return;
    const next = [...flipped, card.id];
    setFlipped(next);
    if (next.length === 2) {
      setLock(true);
      const [a, b] = next.map((id) => deck.find((c) => c.id === id));
      setTimeout(() => {
        if (a.val === b.val) setMatched((m) => [...m, a.id, b.id]);
        setFlipped([]);
        setLock(false);
      }, 650);
    }
  };

  const pairsMatched = matched.length / 2;

  const onContinue = () => {
    unlock("scratch");
    navigate("/quest/scratch");
  };

  return (
    <div>
      <Tag>one more surprise</Tag>
      <h2 className="mt-2 italic text-xl sm:text-2xl" style={{ fontFamily: "'Playfair Display', serif" }}>
        match the pairs
      </h2>

      <div className="grid grid-cols-4 gap-2 sm:gap-2.5 mt-5 w-full max-w-xs sm:max-w-sm mx-auto">
        {deck.map((card) => {
          const isFlipped = flipped.includes(card.id) || matched.includes(card.id);
          const isMatched = matched.includes(card.id);
          return (
            <div
              key={card.id}
              onClick={() => handleFlip(card)}
              className="aspect-square rounded-lg flex items-center justify-center text-lg sm:text-2xl cursor-pointer select-none transition-all duration-300"
              style={{
                background: isFlipped ? COLORS.creamDeep : `linear-gradient(135deg, ${COLORS.rust}, ${COLORS.rustSoft})`,
                opacity: isMatched ? 0.35 : 1,
                cursor: isMatched ? "default" : "pointer",
              }}
            >
              {isFlipped ? card.val : "✦"}
            </div>
          );
        })}
      </div>

      <div className="mt-3.5 text-sm" style={{ color: COLORS.brownSoft }}>
        {pairsMatched === PUZZLE_EMOJIS.length ? "all matched! 🎉" : `${pairsMatched} / ${PUZZLE_EMOJIS.length} pairs matched`}
      </div>

      {pairsMatched === PUZZLE_EMOJIS.length && (
        <Btn onClick={onContinue} className="mt-4">
          continue
        </Btn>
      )}
    </div>
  );
}