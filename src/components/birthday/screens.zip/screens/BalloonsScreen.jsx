import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { COLORS, WISHES, BALLOON_COLORS } from "../constants";
import { useQuestProgress } from "../hooks/useQuestProgress";
import Tag from "../shared/Tag";
import Btn from "../shared/Btn";

export default function BalloonsScreen() {
  const navigate = useNavigate();
  const { unlock } = useQuestProgress();
  const [popped, setPopped] = useState(() => Array(WISHES.length).fill(false));
  const [wish, setWish] = useState("");
  const poppedCount = popped.filter(Boolean).length;

  const pop = (i) => {
    if (popped[i]) return;
    const next = [...popped];
    next[i] = true;
    setPopped(next);
    setWish(WISHES[i]);
  };

  const onContinue = () => {
    unlock("puzzle");
    navigate("/quest/puzzle");
  };

  return (
    <div>
      <Tag>pop the wishes</Tag>
      <h2 className="mt-2 italic text-xl sm:text-2xl" style={{ fontFamily: "'Playfair Display', serif" }}>
        pop each balloon
      </h2>

      <div className="relative w-full max-w-md h-64 sm:h-72 mx-auto mt-5">
        {WISHES.map((_, i) => (
          <div
            key={i}
            onClick={() => pop(i)}
            className={`balloon absolute bottom-0 w-11 h-14 sm:w-12 sm:h-16 cursor-pointer ${popped[i] ? "balloon-pop" : "balloon-rise balloon-sway"}`}
            style={{
              left: `${6 + i * 15}%`,
              background: BALLOON_COLORS[i % BALLOON_COLORS.length],
              boxShadow: "inset -6px -6px 10px rgba(0,0,0,0.12), 0 8px 14px rgba(94,70,50,0.2)",
              animationDelay: `${i * 0.3}s, ${i * 0.2}s`,
              opacity: popped[i] ? 0 : 1,
            }}
          />
        ))}
      </div>

      <div className="mt-4 min-h-[2.2em] text-lg sm:text-xl" style={{ fontFamily: "'Alex Brush', cursive", color: COLORS.rust }}>
        {wish && `"${wish}"`}
      </div>
      <div className="mt-1.5 text-xs" style={{ color: COLORS.brownSoft }}>
        {poppedCount} / {WISHES.length} popped
      </div>

      {poppedCount >= WISHES.length && (
        <Btn onClick={onContinue} className="mt-4">
          continue
        </Btn>
      )}
    </div>
  );
}