import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { COLORS } from "../constants";
import { useQuestProgress } from "../hooks/useQuestProgress";
import Tag from "../shared/Tag";
import Btn from "../shared/Btn";

export default function ScratchScreen() {
  const navigate = useNavigate();
  const { unlock } = useQuestProgress();
  const canvasRef = useRef(null);
  const wrapRef = useRef(null);
  const [revealed, setRevealed] = useState(false);
  const scratching = useRef(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");

    const size = () => {
      canvas.width = wrap.clientWidth;
      canvas.height = wrap.clientHeight;
      ctx.fillStyle = "#cbb894";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = "rgba(94,70,50,0.6)";
      ctx.font = "600 14px Nunito, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("scratch here ✦", canvas.width / 2, canvas.height / 2);
    };
    size();

    const getPos = (e) => {
      const rect = canvas.getBoundingClientRect();
      const cx = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
      const cy = (e.touches ? e.touches[0].clientY : e.clientY) - rect.top;
      return { x: cx, y: cy };
    };
    const scratchAt = (x, y) => {
      ctx.globalCompositeOperation = "destination-out";
      ctx.beginPath();
      ctx.arc(x, y, 22, 0, Math.PI * 2);
      ctx.fill();
    };
    const checkRevealed = () => {
      const data = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
      let cleared = 0;
      let total = 0;
      for (let i = 3; i < data.length; i += 4 * 20) {
        total++;
        if (data[i] === 0) cleared++;
      }
      if (cleared / total > 0.45) {
        setRevealed(true);
      }
    };
    const start = (e) => {
      scratching.current = true;
      const p = getPos(e);
      scratchAt(p.x, p.y);
      e.preventDefault();
    };
    const move = (e) => {
      if (!scratching.current) return;
      const p = getPos(e);
      scratchAt(p.x, p.y);
      e.preventDefault();
    };
    const end = () => {
      if (scratching.current) {
        scratching.current = false;
        checkRevealed();
      }
    };

    canvas.addEventListener("mousedown", start);
    canvas.addEventListener("mousemove", move);
    window.addEventListener("mouseup", end);
    canvas.addEventListener("touchstart", start, { passive: false });
    canvas.addEventListener("touchmove", move, { passive: false });
    canvas.addEventListener("touchend", end);

    return () => {
      canvas.removeEventListener("mousedown", start);
      canvas.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", end);
      canvas.removeEventListener("touchstart", start);
      canvas.removeEventListener("touchmove", move);
      canvas.removeEventListener("touchend", end);
    };
  }, []);

  const onContinue = () => {
    unlock("letter");
    navigate("/quest/letter");
  };

  return (
    <div>
      <Tag>last surprise</Tag>
      <h2 className="mt-2 italic text-xl sm:text-2xl" style={{ fontFamily: "'Playfair Display', serif" }}>
        scratch to reveal
      </h2>

      <div
        ref={wrapRef}
        className="relative w-64 h-40 sm:w-72 sm:h-44 mx-auto mt-5 rounded-xl overflow-hidden"
        style={{ boxShadow: "0 16px 30px rgba(94,70,50,0.25)" }}
      >
        <div
          className="absolute inset-0 flex items-center justify-center text-center px-4 text-lg sm:text-xl"
          style={{ background: `linear-gradient(135deg, ${COLORS.cream}, ${COLORS.creamDeep})`, fontFamily: "'Alex Brush', cursive", color: COLORS.rust }}
        >
          <span className="quest-editable">[your final surprise message]</span>
        </div>
        <canvas
          ref={canvasRef}
          className="absolute inset-0 transition-opacity duration-500"
          style={{ opacity: revealed ? 0 : 1, touchAction: "none", cursor: "grab" }}
        />
      </div>

      <div className="mt-3.5 text-sm" style={{ color: COLORS.brownSoft }}>
        {revealed ? "revealed! ✦" : "rub your finger / mouse over the card"}
      </div>

      {revealed && (
        <Btn onClick={onContinue} className="mt-5">
          continue
        </Btn>
      )}
    </div>
  );
}